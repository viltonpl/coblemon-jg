datapack enable Terralith-DP.zip before "cobblemon:repurposedstructurescobblemon"
datapack enable COBBLEVERSE-Sinnoh-DP.zip